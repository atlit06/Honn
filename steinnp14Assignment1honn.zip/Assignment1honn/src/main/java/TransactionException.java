/**
 * Created by steinn on 03/09/16.
 */
/**
 * Exceptions related to the withdrawal methods
 */
public class TransactionException extends Exception {
    public TransactionException(String message) { super(message); };
}
