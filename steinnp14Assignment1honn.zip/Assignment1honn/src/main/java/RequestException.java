/**
 * Created by steinn on 03/09/16.
 */

/**
 * Exception component for handling Request exceptions
 */
public class RequestException extends Exception {
    public RequestException(Exception e) { super(e); }
}
