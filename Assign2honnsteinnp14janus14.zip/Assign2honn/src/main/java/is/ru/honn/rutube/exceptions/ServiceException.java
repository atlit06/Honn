package is.ru.honn.rutube.exceptions;

/**
 * Created by steinn on 28/09/16.
 */
public class ServiceException extends Exception {
    public ServiceException (String message) { super(message); }
}
